let currentChatId = null;

// ─────────────────────────────────────
// Helpers
// ─────────────────────────────────────
function setCurrentChatId(id) {
    currentChatId = id;
    if (id) {
        localStorage.setItem("currentChatId", id);
    } else {
        localStorage.removeItem("currentChatId");
    }
}

function appendMessage(text, sender) {
    const box = document.getElementById("chat-box");
    const div = document.createElement("div");
    div.className = sender === "user" ? "user-message" : "bot-message";
    div.textContent = text;
    box.appendChild(div);
    box.scrollTop = box.scrollHeight;
}

function clearChatBox() {
    document.getElementById("chat-box").innerHTML = "";
}

// ─────────────────────────────────────
// Send message (REQUIRES chat)
// ─────────────────────────────────────
async function sendMessage() {
    if (!currentChatId) {
        alert("Please click 'New Chat' first.");
        return;
    }

    const input = document.getElementById("user-input");
    const msg = input.value.trim();
    if (!msg) return;

    appendMessage(msg, "user");
    input.value = "";

    try {
        const res = await fetch(`/chat/${currentChatId}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message: msg })
        });

        if (!res.ok) throw new Error(`HTTP ${res.status}`);

        const data = await res.json();
        appendMessage(data.response, "bot");

    } catch (err) {
        appendMessage("⚠️ Error: Could not get response.", "bot");
        console.error(err);
    }
}

// ─────────────────────────────────────
// Create NEW chat (ONLY here)
// ─────────────────────────────────────
async function newChat() {
    try {
        const res = await fetch("/new-chat", { method: "POST" });
        if (!res.ok) throw new Error("New chat failed");

        const data = await res.json();
        setCurrentChatId(data.chatId);

        clearChatBox();
        appendMessage("🩺 New medical conversation started.", "bot");

        loadChatHistory();
    } catch (err) {
        console.error("New chat error:", err);
        appendMessage("⚠️ Could not create new chat.", "bot");
    }
}

// ─────────────────────────────────────
// Switch existing chat
// ─────────────────────────────────────
async function switchChat(chatId) {
    try {
        clearChatBox();
        setCurrentChatId(chatId);

        const res = await fetch(`/chat/${chatId}`);
        if (!res.ok) throw new Error("Load failed");

        const data = await res.json();
        data.messages.forEach(m => appendMessage(m.text, m.sender));

        document.querySelectorAll("#chat-history li").forEach(li => {
            li.classList.toggle("active", li.dataset.chatId === chatId);
        });

    } catch (err) {
        appendMessage("⚠️ Could not load this conversation.", "bot");
    }
}

// ─────────────────────────────────────
// Sidebar chat list
// ─────────────────────────────────────
async function loadChatHistory() {
    try {
        const res = await fetch("/chats");
        const data = await res.json();

        const ul = document.getElementById("chat-history");
        ul.innerHTML = "";

        if (data.chats.length === 0) {
            const li = document.createElement("li");
            li.textContent = "No conversations yet";
            li.style.color = "#94a3b8";
            ul.appendChild(li);
            return;
        }

        data.chats.forEach(chat => {
            const li = document.createElement("li");
            li.textContent = chat.title;
            li.dataset.chatId = chat.id;
            li.onclick = () => switchChat(chat.id);

            if (chat.id === currentChatId) {
                li.classList.add("active");
            }

            ul.appendChild(li);
        });
    } catch (err) {
        console.error("History load failed", err);
    }
}

// ─────────────────────────────────────
// Init (NO auto chat)
// ─────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
    // 🚫 ignore old localStorage chatId
    setCurrentChatId(null);
    localStorage.removeItem("currentChatId");

    clearChatBox();
    appendMessage("👋 Click 'New Chat' to start a medical conversation.", "bot");

    loadChatHistory();

    const input = document.getElementById("user-input");
    input.addEventListener("keypress", e => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    input.focus();
});
